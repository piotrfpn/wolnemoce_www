import './globals.css';
import { Inter } from 'next/font/google';
import type { Metadata } from 'next';

// Load the Inter font and assign it to a CSS variable. Tailwind
// references this variable in `tailwind.config.ts` under
// `fontFamily.sans`, ensuring the font is applied globally.
const inter = Inter({
  subsets: ['latin', 'latin-ext'],
  display: 'swap',
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'WolneMoce.pl – wolne moce produkcyjne dla firm',
  description: 'Marketplace B2B łączący firmy szukające podwykonawców z firmami posiadającymi wolne moce produkcyjne, logistyczne i technologiczne.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pl" className={inter.variable}>
      <body>{children}</body>
    </html>
  );
}