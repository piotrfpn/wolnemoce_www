import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import SearchBar from '@/components/SearchBar';
import Categories from '@/components/Categories';

export default function HomePage() {
  return (
    <>
      {/* Always render the top navigation and hero section */}
      <Navbar />
      <Hero />
      {/* Iteration 2: add the search bar and categories sections */}
      <SearchBar />
      <Categories />
    </>
  );
}