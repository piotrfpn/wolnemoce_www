"use client";

import { useState } from 'react';
import type { CSSProperties } from 'react';

/**
 * Navbar component that replicates the structure and styles from the static
 * HTML preview. It includes the logo, navigation links, action buttons and
 * a hamburger toggle for mobile screens. On small screens the links and
 * actions collapse into a dropdown-style menu. FontAwesome icons are used
 * directly via <i> tags as defined in the HTML template.  
 */
export default function Navbar() {
  const [open, setOpen] = useState(false);
  const handleToggle = () => setOpen((prev) => !prev);
  const handleClose = () => setOpen(false);

  // Inline styles for the mobile menu overlay. These values mirror the
  // translucent background and blur used in the original design and
  // ensure the dropdown stretches full width below the fixed navbar.
  const mobileMenuStyle: CSSProperties = {
    position: 'absolute',
    top: '72px',
    left: 0,
    right: 0,
    background: 'rgba(255,255,255,0.95)',
    backdropFilter: 'blur(20px)',
    borderBottom: '1px solid var(--border)',
    padding: '16px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '12px',
    zIndex: 999,
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <a href="#" className="logo" onClick={handleClose}>
          <div className="logo-icon">
            <i className="fas fa-industry"></i>
          </div>
          <div className="logo-text">
            Wolne<span>Moce</span>.pl
          </div>
        </a>
        {/* Desktop navigation links */}
        <ul className="nav-links">
          <li>
            <a href="#oferty" onClick={handleClose}>
              Oferty
            </a>
          </li>
          <li>
            <a href="#kategorie" onClick={handleClose}>
              Branże
            </a>
          </li>
          <li>
            <a href="#jak-to-dziala" onClick={handleClose}>
              Jak to działa
            </a>
          </li>
          <li>
            <a href="#cennik" onClick={handleClose}>
              Cennik
            </a>
          </li>
          <li>
            <a href="#ekspert" onClick={handleClose}>
              Ekspert
            </a>
          </li>
          <li>
            <a href="#blog" onClick={handleClose}>
              Blog
            </a>
          </li>
          <li>
            <a href="#kontakt" onClick={handleClose}>
              Kontakt
            </a>
          </li>
        </ul>
        <div className="nav-actions">
          <a href="#" className="btn btn-sm btn-outline" onClick={handleClose}>
            Zaloguj się
          </a>
          <a href="#" className="btn btn-sm btn-primary" onClick={handleClose}>
            Dodaj ofertę
          </a>
        </div>
        <button
          className="mobile-toggle"
          aria-label="Przełącz menu mobilne"
          onClick={handleToggle}
        >
          {/* Use a FontAwesome icon for the hamburger/close button */}
          <i className={`fas ${open ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
      </div>
      {/* Mobile dropdown menu: shown only when open is true */}
      {open && (
        <div style={mobileMenuStyle}>
          <ul className="nav-links" style={{ flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
            <li>
              <a href="#oferty" onClick={handleClose}>
                Oferty
              </a>
            </li>
            <li>
              <a href="#kategorie" onClick={handleClose}>
                Branże
              </a>
            </li>
            <li>
              <a href="#jak-to-dziala" onClick={handleClose}>
                Jak to działa
              </a>
            </li>
            <li>
              <a href="#cennik" onClick={handleClose}>
                Cennik
              </a>
            </li>
            <li>
              <a href="#ekspert" onClick={handleClose}>
                Ekspert
              </a>
            </li>
            <li>
              <a href="#blog" onClick={handleClose}>
                Blog
              </a>
            </li>
            <li>
              <a href="#kontakt" onClick={handleClose}>
                Kontakt
              </a>
            </li>
          </ul>
          <div className="nav-actions" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <a href="#" className="btn btn-sm btn-outline" onClick={handleClose}>
              Zaloguj się
            </a>
            <a href="#" className="btn btn-sm btn-primary" onClick={handleClose}>
              Dodaj ofertę
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}