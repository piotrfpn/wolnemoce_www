import FadeIn from './FadeIn';
import { UserPlus, FilePlus, Mail, CheckCircle } from 'lucide-react';

const STEPS = [
  {
    title: 'Zarejestruj firmę',
    description:
      'Załóż konto i zweryfikuj swoje dane firmowe, aby zwiększyć wiarygodność na platformie.',
    icon: UserPlus,
  },
  {
    title: 'Dodaj ofertę',
    description:
      'Opisz swoje wolne moce produkcyjne, technologiczne lub logistyczne w kilku prostych krokach.',
    icon: FilePlus,
  },
  {
    title: 'Odbieraj zapytania',
    description:
      'Potencjalni partnerzy biznesowi skontaktują się z Tobą bezpośrednio poprzez portal.',
    icon: Mail,
  },
  {
    title: 'Realizuj zamówienia',
    description:
      'Ustal szczegóły współpracy i zrealizuj zamówienie według indywidualnych potrzeb klienta.',
    icon: CheckCircle,
  },
];

export default function HowItWorks() {
  return (
    <section id="jak-to-dziala" className="container">
      <FadeIn>
        <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-center md:text-left">
          Jak to działa
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {STEPS.map(({ title, description, icon: Icon }, index) => (
            <div key={index} className="flex flex-col items-start">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary text-light mb-4">
                <Icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-dark">
                {title}
              </h3>
              <p className="text-sm text-gray-700">
                {description}
              </p>
            </div>
          ))}
        </div>
      </FadeIn>
    </section>
  );
}