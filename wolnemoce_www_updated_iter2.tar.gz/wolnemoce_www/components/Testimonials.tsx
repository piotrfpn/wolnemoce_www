import FadeIn from './FadeIn';
import { Quote, Star } from 'lucide-react';

interface Testimonial {
  quote: string;
  name: string;
  role: string;
  rating: number;
}

const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      'Dzięki WolneMoce znaleźliśmy sprawdzonych podwykonawców w ciągu kilku dni. Platforma pozwoliła nam szybko skalować produkcję.',
    name: 'Jan Kowalski',
    role: 'Dyrektor Produkcji, MetalPro',
    rating: 5,
  },
  {
    quote:
      'Współpracujemy z wieloma firmami z różnych branż. Transparentne warunki i brak ukrytych opłat to ogromny atut.',
    name: 'Anna Nowak',
    role: 'CEO, Plastix',
    rating: 5,
  },
  {
    quote:
      'Portal umożliwił nam dotarcie do nowych klientów z całej Polski. Polecam każdemu przedsiębiorcy!',
    name: 'Michał Wiśniewski',
    role: 'Właściciel, ElectroWorks',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section id="opinie" className="container">
      <FadeIn>
        <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-center md:text-left">
          Opinie klientów
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map(({ quote, name, role, rating }) => (
            <div
              key={name}
              className="bg-light rounded-lg shadow-card p-6 flex flex-col h-full"
            >
              <Quote className="h-8 w-8 text-secondary mb-4" />
              <p className="flex-1 text-sm text-gray-700">"{quote}"</p>
              <div className="mt-4">
                <div className="flex items-center space-x-1 mb-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star
                      key={i}
                      className={
                        i <= rating ? 'h-4 w-4 text-warning' : 'h-4 w-4 text-muted'
                      }
                    />
                  ))}
                </div>
                <p className="text-sm font-semibold text-dark">{name}</p>
                <p className="text-xs text-gray-600">{role}</p>
              </div>
            </div>
          ))}
        </div>
      </FadeIn>
    </section>
  );
}