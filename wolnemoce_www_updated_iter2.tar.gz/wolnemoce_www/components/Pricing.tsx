import FadeIn from './FadeIn';
import { CheckCircle, BadgeDollarSign, Star } from 'lucide-react';

interface Plan {
  name: string;
  price: string;
  description: string;
  features: string[];
  highlight?: boolean;
}

const PLANS: Plan[] = [
  {
    name: 'FREE',
    price: '0 zł/mies.',
    description: 'Dla firm rozpoczynających przygodę z WolneMoce.pl',
    features: [
      '1 aktywna oferta',
      'Standardowa widoczność',
      '2 zapytania miesięcznie',
      'Podstawowa weryfikacja',
      'Dostęp do bazy wiedzy',
    ],
  },
  {
    name: 'PRO',
    price: '299 zł/mies.',
    description: 'Dla firm pragnących zwiększyć swój zasięg',
    features: [
      'Nielimitowane oferty',
      'Wyróżnienie Top',
      'Nielimitowane zapytania',
      'Złoty Certyfikat Zaufania',
      'Dedykowany opiekun',
    ],
    highlight: true,
  },
  {
    name: 'ENTERPRISE',
    price: 'Indywidualna wycena',
    description: 'Dla dużych przedsiębiorstw i integratorów',
    features: [
      'Nielimitowane oferty + integracja API',
      'Priorytetowa widoczność + kampanie',
      'Nielimitowane zapytania',
      'Pełny audyt',
      'Key Account Manager',
    ],
  },
];

const ADDITIONAL_OPTIONS = [
  { name: 'Wyróżnienie oferty', price: '49 zł / 7 dni' },
  { name: 'Pay‑per‑Lead', price: 'od 29 zł / zapytanie' },
  { name: 'Reklama banerowa', price: '199 zł / mies.' },
];

export default function Pricing() {
  return (
    <section id="cennik" className="container">
      <FadeIn>
        <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-center md:text-left">
          Cennik
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col bg-light rounded-lg shadow-card overflow-hidden ${plan.highlight ? 'border-2 border-secondary' : 'border border-muted'}`}
            >
              {plan.highlight && (
                <span className="absolute right-0 top-0 bg-secondary text-dark text-xs font-semibold px-3 py-1 rounded-bl-md">
                  Najpopularniejszy
                </span>
              )}
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="text-xl font-bold mb-2 text-dark">
                  {plan.name}
                </h3>
                <p className="text-3xl font-extrabold text-primary mb-2">
                  {plan.price}
                </p>
                <p className="text-sm text-gray-700 mb-4">
                  {plan.description}
                </p>
                <ul className="flex-1 space-y-2">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-success mr-2" />
                      <span className="text-sm text-gray-800">{feature}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="#dodaj-oferte"
                  className="mt-6 inline-block text-center rounded-md bg-primary px-4 py-2 text-light font-medium hover:bg-primary/90 transition-colors"
                >
                  Wybierz plan
                </a>
              </div>
            </div>
          ))}
        </div>
        <div className="border-t border-muted pt-6">
          <h3 className="text-lg font-semibold mb-4 text-dark">
            Dodatkowe opcje
          </h3>
          <div className="space-y-2">
            {ADDITIONAL_OPTIONS.map((opt) => (
              <div key={opt.name} className="flex justify-between items-center">
                <span className="text-sm text-gray-800">{opt.name}</span>
                <span className="text-sm font-medium text-primary">
                  {opt.price}
                </span>
              </div>
            ))}
          </div>
          <p className="mt-4 text-sm text-gray-600">
            Transparentne modele współpracy bez ukrytych kosztów.
          </p>
        </div>
      </FadeIn>
    </section>
  );
}