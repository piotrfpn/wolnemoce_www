import { Facebook, Linkedin, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-dark text-light pt-12 pb-8 mt-20">
      <div className="container grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* About and social */}
        <div>
          <h3 className="text-xl font-bold mb-3">WolneMoce</h3>
          <p className="text-sm mb-4">
            Marketplace B2B łączący firmy szukające podwykonawców z
            przedsiębiorstwami posiadającymi wolne moce produkcyjne,
            logistyczne i techniczne.
          </p>
          <div className="flex space-x-4">
            <a
              href="#"
              className="p-2 rounded-full bg-primary text-dark hover:bg-secondary transition-colors"
              aria-label="Facebook"
            >
              <Facebook className="h-4 w-4" />
            </a>
            <a
              href="#"
              className="p-2 rounded-full bg-primary text-dark hover:bg-secondary transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="h-4 w-4" />
            </a>
            <a
              href="#"
              className="p-2 rounded-full bg-primary text-dark hover:bg-secondary transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="h-4 w-4" />
            </a>
          </div>
        </div>
        {/* Navigation links */}
        <div>
          <h4 className="font-semibold mb-3">Nawigacja</h4>
          <ul className="space-y-2 text-sm">
            <li><a href="#oferty" className="hover:underline">Oferty</a></li>
            <li><a href="#kategorie" className="hover:underline">Kategorie</a></li>
            <li><a href="#jak-to-dziala" className="hover:underline">Jak to działa</a></li>
            <li><a href="#cennik" className="hover:underline">Cennik</a></li>
            <li><a href="#blog" className="hover:underline">Blog</a></li>
          </ul>
        </div>
        {/* Categories links */}
        <div>
          <h4 className="font-semibold mb-3">Kategorie</h4>
          <ul className="space-y-2 text-sm">
            <li><a href="#kategorie-metalurgia" className="hover:underline">Metalurgia</a></li>
            <li><a href="#kategorie-tworzywa" className="hover:underline">Tworzywa sztuczne</a></li>
            <li><a href="#kategorie-elektronika" className="hover:underline">Elektronika</a></li>
            <li><a href="#kategorie-automatyka" className="hover:underline">Automatyka</a></li>
            <li><a href="#kategorie-logistyka" className="hover:underline">Logistyka</a></li>
            <li><a href="#kategorie-magazynowanie" className="hover:underline">Magazynowanie</a></li>
          </ul>
        </div>
        {/* Newsletter */}
        <div>
          <h4 className="font-semibold mb-3">Newsletter</h4>
          <p className="text-sm mb-3">
            Zapisz się, aby otrzymywać informacje o nowych ofertach i
            artykułach.
          </p>
          <form onSubmit={(e) => e.preventDefault()} className="flex flex-col space-y-3">
            <input
              type="email"
              placeholder="Twój e-mail"
              className="px-3 py-2 rounded-md border border-gray-600 bg-transparent text-light focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button
              type="submit"
              className="rounded-md bg-primary text-dark px-4 py-2 font-semibold hover:bg-secondary transition-colors"
            >
              Zapisz się
            </button>
          </form>
        </div>
      </div>
      <div className="mt-8 border-t border-gray-800 pt-4 text-center text-xs text-gray-500">
        © {new Date().getFullYear()} WolneMoce.pl. Wszelkie prawa zastrzeżone.
      </div>
    </footer>
  );
}