import FadeIn from './FadeIn';

export default function CtaSection() {
  return (
    <section id="cta" className="container">
      <FadeIn>
        <div className="bg-gradient-to-r from-primary to-secondary rounded-xl p-10 md:p-14 text-center md:text-left text-light flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold mb-2">
              Gotowy, aby rozwijać swój biznes?
            </h2>
            <p className="text-sm sm:text-base">
              Dołącz do WolneMoce.pl już dziś i zacznij korzystać z
              wolnych mocy produkcyjnych najlepszych firm.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#dodaj-oferte"
              className="rounded-md bg-light text-primary px-6 py-3 font-semibold shadow hover:bg-white/90 transition-colors"
            >
              Dodaj ofertę za darmo
            </a>
            <a
              href="#oferty"
              className="rounded-md border-2 border-light text-light px-6 py-3 font-semibold hover:bg-light hover:text-primary transition-colors"
            >
              Przeglądaj oferty
            </a>
          </div>
        </div>
      </FadeIn>
    </section>
  );
}