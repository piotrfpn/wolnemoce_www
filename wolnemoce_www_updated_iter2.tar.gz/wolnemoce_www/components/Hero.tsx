/**
 * Hero section replicating the structure from the HTML preview. This component
 * renders the headline, descriptive text, statistics, call‑to‑action buttons
 * and a sample offer card with floating badges. All classes match those
 * defined in the imported CSS from the HTML template. Do not modify the
 * markup here unless updating the preview HTML.
 */
export default function Hero() {
  return (
    <section className="hero">
      {/* Background pattern overlay */}
      <div className="hero-pattern"></div>
      <div className="hero-content">
        {/* Left text column */}
        <div className="hero-text">
          <div className="hero-badge">
            <i className="fas fa-star"></i> #1 Portal wolnych mocy produkcyjnych w Polsce
          </div>
          <h1>
            Znajdź <span className="highlight">wolne moce</span> produkcyjne dla swojej firmy
          </h1>
          <p className="hero-desc">
            Łączymy firmy poszukujące możliwości produkcyjnych z zakładami, które dysponują
            wolnymi zdolnościami. Szybko, bezpiecznie i efektywnie.
          </p>
          <div className="hero-stats">
            <div className="hero-stat">
              <div className="hero-stat-value">500+</div>
              <div className="hero-stat-label">Aktywnych ofert</div>
            </div>
            <div className="hero-stat">
              <div className="hero-stat-value">200+</div>
              <div className="hero-stat-label">Zweryfikowanych firm</div>
            </div>
            <div className="hero-stat">
              <div className="hero-stat-value">50+</div>
              <div className="hero-stat-label">Zrealizowanych transakcji</div>
            </div>
          </div>
          <div className="hero-actions">
            <a href="#oferty" className="btn btn-accent">
              Przeglądaj oferty
            </a>
            <a
              href="#"
              className="btn"
              style={{
                background: 'rgba(255,255,255,0.15)',
                color: 'white',
                border: '1px solid rgba(255,255,255,0.3)',
              }}
            >
              <i className="fas fa-plus"></i> Dodaj swoją ofertę
            </a>
          </div>
        </div>
        {/* Right visual column */}
        <div className="hero-visual">
          <div className="hero-card">
            <div className="hero-card-header">
              <div className="hero-card-avatar">MP</div>
              <div className="hero-card-info">
                <h4>MetalPol Sp. z o.o.</h4>
                <p>Obróbka CNC · Warszawa</p>
              </div>
            </div>
            <div className="hero-card-body">
              <h5>Obróbka CNC - wolne moce 500 szt/mies.</h5>
              <div className="hero-card-tags">
                <span className="hero-card-tag">CNC 3-osiowy</span>
                <span className="hero-card-tag">CNC 5-osiowy</span>
                <span className="hero-card-tag">ISO 9001</span>
              </div>
            </div>
            <div className="hero-card-footer">
              <div className="hero-card-rating">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star-half-alt"></i>
                <span style={{ marginLeft: '6px', color: 'rgba(255,255,255,0.8)' }}>
                  4.8 (24)
                </span>
              </div>
              <button className="hero-card-btn">Zapytaj o ofertę</button>
            </div>
          </div>
          <div className="floating-badge floating-badge-1">
            <i className="fas fa-check"></i>
            <div className="floating-badge-text">
              <strong>Firma zweryfikowana</strong>
              KRS / CEIDG
            </div>
          </div>
          <div className="floating-badge floating-badge-2">
            <i className="fas fa-shield-alt"></i>
            <div className="floating-badge-text">
              <strong>Gwarancja jakości</strong>
              System recenzji
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}