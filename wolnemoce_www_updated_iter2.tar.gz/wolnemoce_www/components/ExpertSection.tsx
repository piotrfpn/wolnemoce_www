import FadeIn from './FadeIn';
import { ShieldCheck, PiggyBank, Users, FileText } from 'lucide-react';

const POINTS = [
  {
    title: 'Zweryfikowani partnerzy',
    description:
      'Dbamy o bezpieczeństwo Twojej firmy. Każdy użytkownik przechodzi weryfikację KRS/CEIDG, aby zapewnić transparentność współpracy.',
    icon: ShieldCheck,
  },
  {
    title: 'Optymalizacja kosztów',
    description:
      'Przejrzysty model subskrypcyjny pozwala dobrać pakiet do potrzeb Twojego biznesu bez prowizji od transakcji.',
    icon: PiggyBank,
  },
  {
    title: 'Bezpośrednie relacje B2B',
    description:
      'Kontaktujesz się bezpośrednio z partnerami biznesowymi – bez pośredników i ukrytych opłat.',
    icon: Users,
  },
  {
    title: 'Wsparcie formalne',
    description:
      'Oferujemy wzory umów i dokumentacji, które ułatwiają rozpoczęcie współpracy w zgodzie z przepisami.',
    icon: FileText,
  },
];

export default function ExpertSection() {
  return (
    <section id="expert" className="container bg-accent rounded-xl p-8 md:p-12">
      <FadeIn>
        <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-dark text-center md:text-left">
          Dlaczego warto nam zaufać
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {POINTS.map(({ title, description, icon: Icon }) => (
            <div key={title} className="flex items-start">
              <div className="flex-shrink-0 mr-4">
                <div className="h-10 w-10 rounded-full bg-primary text-light flex items-center justify-center">
                  <Icon className="h-5 w-5" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-dark mb-1">
                  {title}
                </h3>
                <p className="text-sm text-gray-700">
                  {description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </FadeIn>
    </section>
  );
}