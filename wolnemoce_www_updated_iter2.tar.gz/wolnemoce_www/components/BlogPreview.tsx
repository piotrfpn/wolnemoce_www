import FadeIn from './FadeIn';
import { Calendar, Tag, ArrowRight } from 'lucide-react';

interface Post {
  title: string;
  category: string;
  date: string;
  excerpt: string;
}

const POSTS: Post[] = [
  {
    title: 'Jak wybrać idealnego podwykonawcę? Poradnik dla przedsiębiorców',
    category: 'Poradnik',
    date: '15 kwietnia 2026',
    excerpt:
      'Dowiedz się, na co zwrócić uwagę przy wyborze partnera do współpracy i jak uniknąć najczęstszych błędów.',
  },
  {
    title: 'Case study: optymalizacja magazynu dla branży e‑commerce',
    category: 'Case study',
    date: '2 marca 2026',
    excerpt:
      'Sprawdź, jak wdrożenie nowoczesnych rozwiązań magazynowych pozwoliło skrócić czas realizacji zamówień o 30%.',
  },
  {
    title: 'Trendy w automatyce przemysłowej na 2026 rok',
    category: 'Trendy',
    date: '20 lutego 2026',
    excerpt:
      'Poznaj technologie, które zrewolucjonizują branżę produkcyjną i pozwolą zwiększyć konkurencyjność.',
  },
];

export default function BlogPreview() {
  return (
    <section id="blog" className="container">
      <FadeIn>
        <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-center md:text-left">
          Blog
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {POSTS.map((post) => (
            <div
              key={post.title}
              className="bg-light rounded-lg shadow-card overflow-hidden flex flex-col"
            >
              <div className="h-40 bg-muted" />
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                  <span className="flex items-center space-x-1">
                    <Tag className="h-4 w-4 text-secondary" />
                    <span>{post.category}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4 text-secondary" />
                    <span>{post.date}</span>
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-dark mb-2">
                  {post.title}
                </h3>
                <p className="text-sm text-gray-700 flex-1">
                  {post.excerpt}
                </p>
                <a
                  href="#blog-czytaj"
                  className="mt-4 inline-flex items-center text-primary font-medium hover:underline"
                >
                  Czytaj więcej <ArrowRight className="h-4 w-4 ml-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </FadeIn>
    </section>
  );
}