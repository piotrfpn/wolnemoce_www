import FadeIn from './FadeIn';
import {
  Star,
  CheckCircle,
  ShieldCheck,
  Hammer,
  Bolt,
  Braces,
} from 'lucide-react';

interface Offer {
  title: string;
  company: string;
  description: string;
  location: string;
  rating: number;
  reviews: number;
  features: string[];
  badges?: string[];
}

const OFFERS: Offer[] = [
  {
    title: 'Produkcja elementów stalowych',
    company: 'StalTech Sp. z o.o.',
    description:
      'Specjalizujemy się w precyzyjnej obróbce CNC oraz spawaniu konstrukcji stalowych na zamówienie.',
    location: 'Poznań',
    rating: 4.8,
    reviews: 24,
    features: ['Obróbka CNC', 'Spawanie MIG/MAG'],
    badges: ['Premium', 'Zweryfikowana'],
  },
  {
    title: 'Wtrysk tworzyw sztucznych',
    company: 'Plast-Form S.A.',
    description:
      'Oferujemy usługi wtrysku tworzyw oraz projektowanie form wtryskowych.',
    location: 'Warszawa',
    rating: 4.6,
    reviews: 18,
    features: ['Projektowanie form', 'Produkcja seryjna'],
    badges: ['Zweryfikowana'],
  },
  {
    title: 'Montaż układów elektronicznych',
    company: 'ElectroFix Sp. z o.o.',
    description:
      'Realizujemy montaż przewlekany THT oraz powierzchniowy SMT w oparciu o najnowsze linie produkcyjne.',
    location: 'Kraków',
    rating: 4.9,
    reviews: 31,
    features: ['Montaż SMT', 'Testy funkcjonalne'],
    badges: ['Premium'],
  },
];

export default function FeaturedOffers() {
  return (
    <section id="oferty" className="container">
      <FadeIn>
        <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-center md:text-left">
          Polecane oferty
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {OFFERS.map((offer) => (
            <div
              key={offer.title}
              className="bg-light rounded-lg shadow-card overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative h-40 bg-muted">
                {/* Badges */}
                {offer.badges?.map((badge) => (
                  <span
                    key={badge}
                    className="absolute top-2 left-2 bg-primary text-light text-xs font-semibold px-2 py-1 rounded mr-2 last:mr-0"
                    style={{ marginLeft: offer.badges!.indexOf(badge) * 60 }}
                  >
                    {badge}
                  </span>
                ))}
              </div>
              <div className="p-4 space-y-3">
                <h3 className="text-lg font-semibold text-dark">
                  {offer.title}
                </h3>
                <p className="text-sm text-gray-700">
                  {offer.description}
                </p>
                <div className="flex flex-wrap items-center gap-2">
                  {offer.features.map((feature) => (
                    <span
                      key={feature}
                      className="flex items-center bg-accent text-sm text-dark px-2 py-1 rounded-md"
                    >
                      {/* Use a simple icon based on feature index for variety */}
                      {offer.features.indexOf(feature) % 3 === 0 && <Hammer className="h-4 w-4 mr-1" />}
                      {offer.features.indexOf(feature) % 3 === 1 && <Bolt className="h-4 w-4 mr-1" />}
                      {offer.features.indexOf(feature) % 3 === 2 && <Braces className="h-4 w-4 mr-1" />}
                      {feature}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-sm text-gray-600">{offer.location}</span>
                  <div className="flex items-center space-x-1">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Star
                        key={i}
                        className={
                          i <= Math.round(offer.rating)
                            ? 'h-4 w-4 text-warning'
                            : 'h-4 w-4 text-muted'
                        }
                      />
                    ))}
                    <span className="text-xs text-gray-600 ml-1">
                      {offer.rating.toFixed(1)} ({offer.reviews})
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </FadeIn>
    </section>
  );
}